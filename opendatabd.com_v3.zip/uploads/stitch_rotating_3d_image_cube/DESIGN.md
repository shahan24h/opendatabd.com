---
name: Synthetic Horizon
colors:
  surface: '#0f1513'
  surface-dim: '#0f1513'
  surface-bright: '#343a39'
  surface-container-lowest: '#090f0e'
  surface-container-low: '#171d1c'
  surface-container: '#1b2120'
  surface-container-high: '#252b2a'
  surface-container-highest: '#303635'
  on-surface: '#dee4e1'
  on-surface-variant: '#e6bdbb'
  inverse-surface: '#dee4e1'
  inverse-on-surface: '#2b3230'
  outline: '#ad8886'
  outline-variant: '#5d3f3e'
  surface-tint: '#ffb3b1'
  primary: '#ffb3b1'
  on-primary: '#680011'
  primary-container: '#ff535b'
  on-primary-container: '#5b000e'
  inverse-primary: '#bf0028'
  secondary: '#83d7b4'
  on-secondary: '#003828'
  secondary-container: '#00694d'
  on-secondary-container: '#91e6c2'
  tertiary: '#c6c6c7'
  on-tertiary: '#2f3131'
  tertiary-container: '#909191'
  on-tertiary-container: '#282a2a'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad8'
  primary-fixed-dim: '#ffb3b1'
  on-primary-fixed: '#410007'
  on-primary-fixed-variant: '#92001c'
  secondary-fixed: '#9ef4d0'
  secondary-fixed-dim: '#83d7b4'
  on-secondary-fixed: '#002116'
  on-secondary-fixed-variant: '#00513b'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c7'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#454747'
  background: '#0f1513'
  on-background: '#dee4e1'
  surface-variant: '#303635'
typography:
  display:
    fontFamily: Sora
    fontSize: 64px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Sora
    fontSize: 40px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Sora
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Sora
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Sora
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Sora
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Sora
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Sora
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 16px
  md: 24px
  lg: 40px
  xl: 64px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 48px
---

## Brand & Style

The design system embodies a "Cyber-Patriot" aesthetic, merging high-tech futurism with a soul-stirring color palette inspired by national heritage. It is designed for forward-thinking platforms that value strength, resilience, and cutting-edge performance.

The style is **Modern/High-Tech** with a focus on deep atmospheric depth. It utilizes high-contrast accents against a dark foundation to create a sense of focused energy. Expect precision-engineered layouts, sharp geometric patterns, and a subtle "glow" that suggests active, pulsing data. The emotional response is one of authority and technological prowess, balanced by a grounded, organic undertone.

## Colors

This design system uses a high-impact, dark-mode-first palette. The primary color is a vibrant, aggressive Red (#F42A41), used for calls to action, critical alerts, and high-energy focal points. This is balanced by a deep, resonant Bottle Green (#006A4E) which serves as the secondary color, providing a rich, organic foundation for containers and surface accents.

The background uses a "Deep Void" approach—a near-black neutral with a slight green tint to maintain harmony. Text is primarily off-white for high legibility without the harshness of pure white. Gradients should transition from the deep green into the vibrant red only in high-impact display areas, creating a "horizon" effect.

## Typography

The typography is powered exclusively by **Sora**. Chosen for its geometric clarity and futuristic character, it provides a distinctive voice across all touchpoints. 

Headlines should utilize the heavier weights (700-800) to command attention, often paired with slightly tighter letter spacing to emphasize the "engineered" feel. Body text remains airy and legible with generous line heights. Labels and technical metadata should be set in uppercase with increased letter spacing to evoke a digital-interface or "HUD" (Heads-Up Display) aesthetic.

## Layout & Spacing

The layout follows a **Fluid Grid** system based on a 12-column structure for desktop and a 4-column structure for mobile. Spacing is derived from a 4px base unit to ensure mathematical precision and alignment.

- **Desktop:** 12 columns, 24px gutters, 48px side margins.
- **Tablet:** 8 columns, 24px gutters, 32px side margins.
- **Mobile:** 4 columns, 16px gutters, 16px side margins.

Content should feel structured and modular. Use "Safe Areas" around interactive elements to maintain the high-tech, spacious feel. Large sections of content should be separated by substantial vertical margins (64px+) to prevent visual clutter and maintain the minimalist "horizon" aesthetic.

## Elevation & Depth

Depth in this design system is created through **Tonal Layers** and **Subtle Glows** rather than traditional drop shadows.

1.  **Base Surface:** The deepest green-black neutral.
2.  **Raised Surfaces:** A slightly lighter shade of the deep green, used for cards and panels.
3.  **Active Elements:** Elements that are interactive or high-priority feature a subtle 1px inner border in the primary red or secondary green.
4.  **Luminescence:** Instead of shadows, use "Outer Glows" for active states. A soft, low-opacity red blur behind a primary button creates a "powered-on" effect. 

Avoid heavy, opaque shadows; keep all depth indicators semi-transparent and light-based to simulate a digital screen interface.

## Shapes

The shape language is **Soft (0.25rem)**. This subtle rounding softens the aggressive color palette and geometric typography, making the interface feel sophisticated rather than abrasive. 

- **Small Components:** (Buttons, Inputs, Tags) 4px radius.
- **Medium Components:** (Cards, Modals) 8px radius.
- **Large Components:** (Hero Containers) 12px radius.

Maintain strict 90-degree alignments for the overall grid, using the subtle corner radii only on individual containers to provide a polished, premium finish.

## Components

### Buttons
Primary buttons are solid Primary Red with White text. Hover states should introduce a secondary green glow or a slight scale increase. Secondary buttons use a Deep Green outline with an ghost-fill.

### Input Fields
Fields should have a dark background, slightly lighter than the base surface, with a 1px Deep Green border. On focus, the border transitions to Primary Red with a subtle inner glow.

### Cards
Cards use a subtle gradient background: from the deep neutral to a faint Deep Green at the top-left corner. Borders are minimal (1px) and low-contrast.

### Chips & Labels
Used for categorization, chips should be styled as "indicators"—small, uppercase text with a leading dot colored in either Red or Green to signify status or category.

### Navigation
Top navigation should be semi-transparent with a backdrop blur (Glassmorphism), allowing the background "horizon" colors to bleed through as the user scrolls. Use the Primary Red for active menu indicators (a simple 2px underline or side-bar).